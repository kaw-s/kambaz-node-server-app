export default [
  
    {
      _id: "A101",
      title: "Propulsion Assignment",
      course: "RS101",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A102",
      title: "Combustion Analysis",
      course: "RS101",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A103",
      title: "Nozzle Design Project",
      course: "RS101",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A201",
      title: "Aerodynamics Quiz",
      course: "RS102",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A202",
      title: "Flow Analysis",
      course: "RS102",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A203",
      title: "Heating Analysis",
      course: "RS102",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A301",
      title: "Structural Design Task",
      course: "RS103",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A302",
      title: "Orbital Calculations",
      course: "RS103",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      description:
        "This assignment requires you to demonstrate your understanding of the course material.",
      points: "100",
    },
    {
      _id: "A303",
      title: "Systems Engineering Exam",
      course: "RS103",
      dueDate: "2025-05-24",
      availableDate: "2025-05-24",
      availableUntil: "2025-05-24",
      points: "100",
    },

];
